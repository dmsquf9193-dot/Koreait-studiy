package kr.co.secondproject.users.controller;

import java.util.List;

import org.springframework.stereotype.Controller;

import kr.co.secondproject.users.dto.EmployeeCreateRequestDto;
import kr.co.secondproject.users.dto.EmployeeUpdateRequestDto;
import kr.co.secondproject.users.service.Impl.EmployeeService;
import lombok.*;


@Tag(name = "Employee", description = "직원 관리 API")
@Controller
@RequestMapping("/employee")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;

    @Operation(
        summary = "직원 조회",
        description = "전체 직원 조회, 재직자 조회, 이름 검색을 하나의 API로 처리합니다."
    )
    @GetMapping
    public ResponseEntity<List<EmployeeResponseDto>> getEmployees(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String status) {

        List<EmployeeResponseDto> result = employeeService.getEmployees(name, status);
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "직원 등록", description = "직원을 등록합니다.")
    @PostMapping
    public ResponseEntity<EmployeeResponseDto> createEmployee(
            @RequestBody EmployeeCreateRequestDto requestDto) {

        EmployeeResponseDto result = employeeService.createEmployee(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }

    @Operation(summary = "직원 수정", description = "직원 정보를 부분 수정합니다.")
    @PatchMapping("/{id}")
    public ResponseEntity<EmployeeResponseDto> updateEmployee(
            @PathVariable Long id,
            @RequestBody EmployeeUpdateRequestDto requestDto) {

        EmployeeResponseDto result = employeeService.updateEmployee(id, requestDto);
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "직원 퇴사 처리", description = "직원의 상태를 RESIGNED로 변경하고 퇴사일을 저장합니다.")
    @PatchMapping("/{id}/resign")
    public ResponseEntity<Void> resignEmployee(@PathVariable Long id) {
        employeeService.resignEmployee(id);
        return ResponseEntity.noContent().build();
    }
}