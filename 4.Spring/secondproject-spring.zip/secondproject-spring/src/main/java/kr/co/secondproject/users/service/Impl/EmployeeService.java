package kr.co.secondproject.users.service.Impl;

import java.util.List;

import kr.co.secondProject.users.dto.EmployeeCreateRequestDto;
import kr.co.secondProject.users.dto.EmployeeResponseDto;
import kr.co.secondProject.users.dto.EmployeeUpdateRequestDto;



public interface EmployeeService {

    List<EmployeeResponseDto> getEmployees(String name, String status);

    EmployeeResponseDto createEmployee(EmployeeCreateRequestDto requestDto);

    EmployeeResponseDto updateEmployee(Long id, EmployeeUpdateRequestDto requestDto);

    void resignEmployee(Long id);
}