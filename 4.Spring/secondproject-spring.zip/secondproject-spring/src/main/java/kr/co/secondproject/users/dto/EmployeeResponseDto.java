package kr.co.secondproject.users.dto;

import java.time.LocalDateTime;

import kr.co.secondProject.users.entity.Employee;


@Override
@Transactional
public EmployeeResponseDto createEmployee(EmployeeCreateRequestDto requestDto) {
    String encodedPassword = passwordEncoder.encode(requestDto.getPassword());

    Employee employee = Employee.create(
            requestDto.getEmpId(),
            requestDto.getName(),
            requestDto.getEmail(),
            encodedPassword,
            requestDto.getHireDate(),
            requestDto.getStatus(),
            requestDto.getRole(),
            requestDto.getPosition(),
            requestDto.getDpNum()
    );

    Employee savedEmployee = employeeManageRepository.save(employee);
    return EmployeeResponseDto.from(savedEmployee);
}